# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
raw_logs = dataiku.Dataset("raw_logs")
raw_logs_df = raw_logs.get_dataframe()
# drop the columns visitors_params, sessions_params, and event_params
#drop type, all values are page 
raw_logs_df = raw_logs_df.drop(['visitor_params', 'session_params', 'event_params',
                                'type', 'client_addr','location','session_id', 'visitor_id'], axis=1)
# # assumed the rest of the customer boolean values are zeros 
# for simple and quick data balancing, bootstrap the data to balance the data where customer = 1, with a factor of 3 
df_customer = raw_logs_df[raw_logs_df['customer'] == 1]
raw_logs_df = raw_logs_df.append([df_customer]*2, ignore_index=True)
raw_logs_df['server_ts'] = pd.to_datetime(raw_logs_df['server_ts'])
#split server_ts into year, month, day, and hour
raw_logs_df['server_ts'] = raw_logs_df['server_ts'].dt.strftime('%Y-%m-%d-%H')

#if df["'br_lang'"] is Nan, replace with 'other'
# for languages that start with xx-, group all of them into xx
raw_logs_df['br_lang'] = raw_logs_df['br_lang'].apply(lambda x: x.split('-')[0])
common_langs = raw_logs_df['br_lang'].value_counts()
common_langs = common_langs[common_langs > 10]
# for languages that have counts less than 10, group them in an 'other' category
raw_logs_df['br_lang'] = raw_logs_df['br_lang'].apply(lambda x: x if x in common_langs else 'other')
# for languages that start with xx-, group all of them into xx
#if df["'referer'"] is Nan, replace with 'other'
raw_logs_df['referer'] = raw_logs_df['referer'].fillna('other')
raw_logs_df['referer'] = raw_logs_df['referer'].apply(lambda x: x.split('-')[0])
common_referers = raw_logs_df['referer'].value_counts()
common_referers = common_referers[common_referers > 10]
# for languages that have counts less than 10, group them in an 'other' category
raw_logs_df['referer'] = raw_logs_df['referer'].apply(lambda x: x if x in common_referers else 'other')
# recategorize user_guide to lower categories
temp = raw_logs_df.user_agent.values.tolist()
final_cats = []
keywords = ['windows', 'macintosh', 'linux', 'other']
for i in temp:
    if any(x in i.lower() for x in keywords):
        # get the first keyword that matches
        for x in keywords:
            if x in i.lower():
                final_cats.append(x)
                break
    else:
        final_cats.append('other')
raw_logs_df['user_agent'] = final_cats
raw_logs_df = raw_logs_df.fillna(0)
# Write recipe outputs
raw_logs_cleaned_df = raw_logs_df # For this sample code, simply copy input to output
# Write recipe outputs
raw_logs_cleaned = dataiku.Dataset("raw_logs_cleaned")
raw_logs_cleaned.write_with_schema(raw_logs_cleaned_df)